<?php header('Access-Control-Allow-Origin: *');

echo "
    if(navigator.onLine){
        console.log('ONLine-s');
    }else{
        console.log('OFFLine-s');
    }
";

?>