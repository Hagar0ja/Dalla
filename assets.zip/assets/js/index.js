let chance = 'l',
    mode = 'computer',
    eatOnly = !1,
    error = 0,
    beginAlert = document.getElementsByClassName('begining-alert')[0];

function press(_0xaf38x8) {
    var _0xaf38x9;
    'computer' == mode && 'f' == chance || (null == (_0xaf38x9 = document.getElementsByClassName('selected')[0]) ? null != _0xaf38x8.children[0] && _0xaf38x8.children[0].classList[0] == chance && (makSound('selectedSound'), _0xaf38x8.classList.add('selected')) : null == _0xaf38x8.children[0] ? move(_0xaf38x8, _0xaf38x9) : null != _0xaf38x8.children[0] && null != _0xaf38x9.children[0] && _0xaf38x8.children[0].classList[0] == _0xaf38x9.children[0].classList[0] && (removeSelected(), makSound('selectedSound'), _0xaf38x8.classList.add('selected')))
}

function move(_0xaf38x8, _0xaf38x9) {
    error = 0, (_0xaf38x8.classList.contains('5') || _0xaf38x8.classList.contains('10') || _0xaf38x8.classList.contains('15') || _0xaf38x8.classList.contains('20') || _0xaf38x8.classList.contains('25') || _0xaf38x9 != _0xaf38x8.nextElementSibling) && (_0xaf38x8.classList.contains('1') || _0xaf38x8.classList.contains('6') || _0xaf38x8.classList.contains('11') || _0xaf38x8.classList.contains('16') || _0xaf38x8.classList.contains('21') || _0xaf38x9 != _0xaf38x8.previousElementSibling) && (_0xaf38x8.classList.contains('1') || _0xaf38x8.classList.contains('2') || _0xaf38x8.classList.contains('3') || _0xaf38x8.classList.contains('4') || _0xaf38x8.classList.contains('5') || Number(_0xaf38x8.classList[1]) != Number(_0xaf38x9.classList[1]) + 5) && (_0xaf38x8.classList.contains('21') || _0xaf38x8.classList.contains('22') || _0xaf38x8.classList.contains('23') || _0xaf38x8.classList.contains('24') || _0xaf38x8.classList.contains('25') || Number(_0xaf38x8.classList[1]) != Number(_0xaf38x9.classList[1]) - 5) || eatOnly ? _0xaf38x9.classList.contains('5') || _0xaf38x9.classList.contains('4') || _0xaf38x9.classList.contains('10') || _0xaf38x9.classList.contains('9') || _0xaf38x9.classList.contains('15') || _0xaf38x9.classList.contains('14') || _0xaf38x9.classList.contains('20') || _0xaf38x9.classList.contains('19') || _0xaf38x9.classList.contains('25') || _0xaf38x9.classList.contains('4') || _0xaf38x8 != _0xaf38x9.nextElementSibling.nextElementSibling || null == _0xaf38x9.nextElementSibling.children[0] || _0xaf38x9.nextElementSibling.children[0].classList[0] == _0xaf38x9.children[0].classList[0] ? _0xaf38x9.classList.contains('1') || _0xaf38x9.classList.contains('2') || _0xaf38x9.classList.contains('6') || _0xaf38x9.classList.contains('7') || _0xaf38x9.classList.contains('11') || _0xaf38x9.classList.contains('12') || _0xaf38x9.classList.contains('16') || _0xaf38x9.classList.contains('17') || _0xaf38x9.classList.contains('21') || _0xaf38x9.classList.contains('22') || _0xaf38x8 != _0xaf38x9.previousElementSibling.previousElementSibling || null == _0xaf38x9.previousElementSibling.children[0] || _0xaf38x9.previousElementSibling.children[0].classList[0] == _0xaf38x9.children[0].classList[0] ? _0xaf38x9.classList.contains('1') || _0xaf38x9.classList.contains('6') || _0xaf38x9.classList.contains('2') || _0xaf38x9.classList.contains('7') || _0xaf38x9.classList.contains('3') || _0xaf38x9.classList.contains('8') || _0xaf38x9.classList.contains('4') || _0xaf38x9.classList.contains('9') || _0xaf38x9.classList.contains('5') || _0xaf38x9.classList.contains('10') || Number(_0xaf38x8.classList[1]) != Number(_0xaf38x9.classList[1]) - 10 || null == document.getElementsByClassName((Number(_0xaf38x9.classList[1]) - 5).toString())[0].children[0] || document.getElementsByClassName((Number(_0xaf38x9.classList[1]) - 5).toString())[0].children[0].classList[0] == _0xaf38x9.children[0].classList[0] ? _0xaf38x9.classList.contains('16') || _0xaf38x9.classList.contains('21') || _0xaf38x9.classList.contains('17') || _0xaf38x9.classList.contains('22') || _0xaf38x9.classList.contains('18') || _0xaf38x9.classList.contains('23') || _0xaf38x9.classList.contains('19') || _0xaf38x9.classList.contains('24') || _0xaf38x9.classList.contains('20') || _0xaf38x9.classList.contains('25') || Number(_0xaf38x8.classList[1]) != Number(_0xaf38x9.classList[1]) + 10 || null == document.getElementsByClassName((Number(_0xaf38x9.classList[1]) + 5).toString())[0].children[0] || document.getElementsByClassName((Number(_0xaf38x9.classList[1]) + 5).toString())[0].children[0].classList[0] == _0xaf38x9.children[0].classList[0] ? reject() : eat(_0xaf38x8, document.getElementsByClassName((Number(_0xaf38x9.classList[1]) + 5).toString())[0], _0xaf38x9) : eat(_0xaf38x8, document.getElementsByClassName((Number(_0xaf38x9.classList[1]) - 5).toString())[0], _0xaf38x9) : eat(_0xaf38x8, _0xaf38x8.nextElementSibling, _0xaf38x9) : eat(_0xaf38x8, _0xaf38x8.previousElementSibling, _0xaf38x9) : (_0xaf38x8.appendChild(_0xaf38x9.children[0]), makSound('moveSound'), removeSelected(), ('computer' == mode ? atuoPlay : changeChance)())
}

function chances() {
    var _0xaf38x8 = new Date;
    new Date('2/15/2025') < _0xaf38x8 && setTimeout(() => {
        beginAlert.style.display = 'block', document.getElementById('last').style.display = 'flex', beginAlert.innerHTML = "<div id='last' style='display: flex'><div><div style='text-align: center;font-weight: bold'><span style='color: red' >هذا النسخة التجريبة سينتهي بتاريخ 2025/2/15 الرجاء التحديث  الي اخر اصدار من الرابط</span></div></div><div class='skip' style='osition: relative;z-index: 1;' ><a href='https://t.me/+2EbpSgZw4yxhMmM0' target='_blank' >رابط التحديث</a></div></div>"
    }, 50)
}

function eat(_0xaf38x9, _0xaf38x8, _0xaf38xd, _0xaf38xe) {
    error = 0, makSound('eatSound');
    var _0xaf38xf = _0xaf38xd.offsetLeft,
        _0xaf38x10 = _0xaf38xd.offsetTop;
    _0xaf38x9.appendChild(_0xaf38xd.children[0]), jump(_0xaf38x9.children[0], _0xaf38xf, _0xaf38x10, _0xaf38xe), setTimeout(() => {
        'f' == _0xaf38x8.children[0].classList[0] ? (out2.appendChild(_0xaf38x8.children[0]), jump(out2.lastElementChild, _0xaf38x8.offsetLeft, _0xaf38x8.offsetTop, _0xaf38xe)) : (out1.appendChild(_0xaf38x8.children[0]), jump(out1.lastElementChild, _0xaf38x8.offsetLeft, _0xaf38x8.offsetTop, _0xaf38xe)), setTimeout(() => {
            var _0xaf38x8 = _0xaf38x9.children[0];
            (_0xaf38x9.classList.contains('5') || _0xaf38x9.classList.contains('4') || _0xaf38x9.classList.contains('10') || _0xaf38x9.classList.contains('9') || _0xaf38x9.classList.contains('15') || _0xaf38x9.classList.contains('14') || _0xaf38x9.classList.contains('20') || _0xaf38x9.classList.contains('19') || _0xaf38x9.classList.contains('25') || _0xaf38x9.classList.contains('24') || null == _0xaf38x9.nextElementSibling.children[0] || _0xaf38x9.nextElementSibling.children[0].classList[0] == _0xaf38x8.classList[0] || null == _0xaf38x9.nextElementSibling.nextElementSibling || null != _0xaf38x9.nextElementSibling.nextElementSibling.children[0]) && (_0xaf38x9.classList.contains('1') || _0xaf38x9.classList.contains('2') || _0xaf38x9.classList.contains('6') || _0xaf38x9.classList.contains('7') || _0xaf38x9.classList.contains('11') || _0xaf38x9.classList.contains('12') || _0xaf38x9.classList.contains('16') || _0xaf38x9.classList.contains('17') || _0xaf38x9.classList.contains('21') || _0xaf38x9.classList.contains('22') || null == _0xaf38x9.previousElementSibling.children[0] || _0xaf38x9.previousElementSibling.children[0].classList[0] == _0xaf38x8.classList[0] || null == _0xaf38x9.previousElementSibling.previousElementSibling || null != _0xaf38x9.previousElementSibling.previousElementSibling.children[0]) && (_0xaf38x9.classList.contains('1') || _0xaf38x9.classList.contains('6') || _0xaf38x9.classList.contains('2') || _0xaf38x9.classList.contains('7') || _0xaf38x9.classList.contains('3') || _0xaf38x9.classList.contains('8') || _0xaf38x9.classList.contains('4') || _0xaf38x9.classList.contains('9') || _0xaf38x9.classList.contains('5') || _0xaf38x9.classList.contains('10') || null == document.getElementsByClassName((Number(_0xaf38x9.classList[1]) - 5).toString())[0].children[0] || document.getElementsByClassName((Number(_0xaf38x9.classList[1]) - 5).toString())[0].children[0].classList[0] == _0xaf38x9.children[0].classList[0] || null != document.getElementsByClassName((Number(_0xaf38x9.classList[1]) - 10).toString())[0].children[0]) && (_0xaf38x9.classList.contains('16') || _0xaf38x9.classList.contains('21') || _0xaf38x9.classList.contains('17') || _0xaf38x9.classList.contains('22') || _0xaf38x9.classList.contains('18') || _0xaf38x9.classList.contains('23') || _0xaf38x9.classList.contains('19') || _0xaf38x9.classList.contains('24') || _0xaf38x9.classList.contains('20') || _0xaf38x9.classList.contains('25') || null == document.getElementsByClassName((Number(_0xaf38x9.classList[1]) + 5).toString())[0].children[0] || document.getElementsByClassName((Number(_0xaf38x9.classList[1]) + 5).toString())[0].children[0].classList[0] == _0xaf38x9.children[0].classList[0] || null != document.getElementsByClassName((Number(_0xaf38x9.classList[1]) + 10).toString())[0].children[0]) ? (removeSelected(), checkWinner(), eatOnly = !1, 'computer' == mode ? setTimeout(() => {
                atuoPlay()
            }, 1e3) : changeChance()) : (removeSelected(), eatOnly = !0, _0xaf38x9.classList.add('selected'), setTimeout(() => {
                makSound('eat2Sound'), removeSelected(), checkWinner(), eatOnly = !1, setTimeout(() => {
                    null != _0xaf38x9.children[0] && _0xaf38x9.children[0].classList[0] == chance && ('computer' == mode ? atuoPlay : changeChance)()
                }, 300)
            }, 4e3))
        }, 200)
    }, 530)
}

function changeChance() {
    chance = 'l' == chance ? 'f' : 'l', seleckChance()
}

function removeSelected(_0xaf38x8) {
    null != document.getElementsByClassName('selected')[0] && document.getElementsByClassName('selected')[0].classList.remove('selected')
}

function reject() {}

function checkWinner() {
    12 == out1.childElementCount ? Winner('1', out2.firstElementChild) : 12 == out2.childElementCount && Winner('2', out1.firstElementChild)
}

function Winner(_0xaf38x8, _0xaf38x9) {
    setTimeout(() => {
        beginAlert.style.display = 'block', document.getElementById('last').style.display = 'flex', beginAlert.innerHTML = "<div id='last' ><div class='confetti'><div class='confetti-piece'></div><div class='confetti-piece'></div><div class='confetti-piece'></div><div class='confetti-piece'></div><div class='confetti-piece'></div><div class='confetti-piece'></div><div class='confetti-piece'></div><div class='confetti-piece'></div><div class='confetti-piece'></div><div class='confetti-piece'></div><div class='confetti-piece'></div><div class='confetti-piece'></div><div class='confetti-piece'></div></div><button><div><span>الفائز هو الاعب" + _0xaf38x8 + `</span></div></button><div class='skip' style='osition: relative;z-index: 1;' onclick="location.href = 'index.html?replay'" >اعادة اللعب </div></div>`, beginAlert.firstElementChild.style.display = 'flex', beginAlert.firstElementChild.style.display = 'flex', beginAlert.firstElementChild.firstElementChild.firstElementChild.prepend(_0xaf38x9), beginAlert.firstElementChild.style.display = 'flex', makSound('winSound')
    }, 800)
}

function playMode(_0xaf38x8) {
    makSound('clickSound'), mode = _0xaf38x8.id, _0xaf38x8.parentElement.style.display = 'none', last.style.display = 'flex'
}

function selectedColor(_0xaf38x9) {
    makSound('clickSound');
    let _0xaf38x8 = document.querySelectorAll('.f'),
        _0xaf38xd = document.querySelectorAll('.l');
    _0xaf38x8.forEach((_0xaf38x8) => {
        _0xaf38x8.classList.add('f' + _0xaf38x9)
    }), _0xaf38xd.forEach((_0xaf38x8) => {
        _0xaf38x8.classList.add('l' + _0xaf38x9)
    }), stratGame(), last.style.display = 'none', beginAlert.style.display = 'none', 'computer' == mode && atuoPlay()
}

function stratGame(_0xaf38x8) {
    makSound('begningSound'), 'computer' == mode || 'firend' == mode && seleckChance()
}

function seleckChance() {
    let _0xaf38x8 = document.querySelectorAll('.f'),
        _0xaf38x9 = document.querySelectorAll('.l');
    document.querySelectorAll('.chance').forEach((_0xaf38x8) => {
        _0xaf38x8.classList.remove('chance')
    }), 'f' == chance ? _0xaf38x8.forEach((_0xaf38x8) => {
        _0xaf38x8.classList.add('chance')
    }) : _0xaf38x9.forEach((_0xaf38x8) => {
        _0xaf38x8.classList.add('chance')
    })
}

function jump(_0xaf38x8, _0xaf38x9, _0xaf38xd) {
    _0xaf38x8.style.position = 'absolute';
    var _0xaf38xe = _0xaf38x8.parentElement.offsetLeft + 7,
        _0xaf38xf = _0xaf38x8.parentElement.offsetTop + 7;
    _0xaf38x8.style.left = _0xaf38x9 + 7 + 'px', _0xaf38x8.style.top = _0xaf38xd + 7 + 'px', setTimeout(() => {
        _0xaf38x8.style.transition = 'left .37s linear 0s,top .35s linear 0s', setTimeout(() => {
            _0xaf38x8.style.left = _0xaf38xe + 'px', _0xaf38x8.style.top = _0xaf38xf + 'px', setTimeout(() => {
                _0xaf38x8.style.position = 'unset'
            }, 400)
        }, 50)
    }, 30)
}

function atuoPlay(_0xaf38x8) {
    error = 0, changeChance();
    let _0xaf38x9 = null,
        _0xaf38xd = document.getElementsByClassName('f'),
        _0xaf38xe = [],
        _0xaf38xf = !1;
    for (let _0xaf38x8 = 0; _0xaf38x8 < _0xaf38xd.length; _0xaf38x8++) {
        _0xaf38xd[_0xaf38x8].parentElement.classList.contains('points') && _0xaf38xe.push(_0xaf38xd[_0xaf38x8])
    };
    _0xaf38xd = _0xaf38xe.sort(function () {
        return Math.random() - 0.5
    }), setTimeout(() => {
        for (let _0xaf38x8 = 0; _0xaf38x8 < _0xaf38xd.length; _0xaf38x8++) {
            if (_0xaf38x9 = _0xaf38xd[_0xaf38x8].parentElement, !(_0xaf38x9.classList.contains('5') || _0xaf38x9.classList.contains('4') || _0xaf38x9.classList.contains('10') || _0xaf38x9.classList.contains('9') || _0xaf38x9.classList.contains('15') || _0xaf38x9.classList.contains('14') || _0xaf38x9.classList.contains('20') || _0xaf38x9.classList.contains('19') || _0xaf38x9.classList.contains('25') || _0xaf38x9.classList.contains('4') || null != _0xaf38x9.nextElementSibling.nextElementSibling.children[0] || null == _0xaf38x9.nextElementSibling.children[0] || _0xaf38x9.nextElementSibling.children[0].classList[0] == _0xaf38x9.children[0].classList[0])) {
                pcEate(_0xaf38x9.nextElementSibling.nextElementSibling, _0xaf38x9.nextElementSibling, _0xaf38x9), _0xaf38xf = !0;
                break
            };
            if (!(_0xaf38x9.classList.contains('1') || _0xaf38x9.classList.contains('2') || _0xaf38x9.classList.contains('6') || _0xaf38x9.classList.contains('7') || _0xaf38x9.classList.contains('11') || _0xaf38x9.classList.contains('12') || _0xaf38x9.classList.contains('16') || _0xaf38x9.classList.contains('17') || _0xaf38x9.classList.contains('21') || _0xaf38x9.classList.contains('22') || null != _0xaf38x9.previousElementSibling.previousElementSibling.children[0] || null == _0xaf38x9.previousElementSibling.children[0] || _0xaf38x9.previousElementSibling.children[0].classList[0] == _0xaf38x9.children[0].classList[0])) {
                pcEate(_0xaf38x9.previousElementSibling.previousElementSibling, _0xaf38x9.previousElementSibling, _0xaf38x9), _0xaf38xf = !0;
                break
            };
            if (!(_0xaf38x9.classList.contains('1') || _0xaf38x9.classList.contains('6') || _0xaf38x9.classList.contains('2') || _0xaf38x9.classList.contains('7') || _0xaf38x9.classList.contains('3') || _0xaf38x9.classList.contains('8') || _0xaf38x9.classList.contains('4') || _0xaf38x9.classList.contains('9') || _0xaf38x9.classList.contains('5') || _0xaf38x9.classList.contains('10') || null == document.getElementsByClassName((Number(_0xaf38x9.classList[1]) - 5).toString())[0].children[0] || document.getElementsByClassName((Number(_0xaf38x9.classList[1]) - 5).toString())[0].children[0].classList[0] == _0xaf38x9.children[0].classList[0] || null != document.getElementsByClassName((Number(_0xaf38x9.classList[1]) - 10).toString())[0].children[0])) {
                pcEate(document.getElementsByClassName((Number(_0xaf38x9.classList[1]) - 10).toString())[0], document.getElementsByClassName((Number(_0xaf38x9.classList[1]) - 5).toString())[0], _0xaf38x9), _0xaf38xf = !0;
                break
            };
            if (!(_0xaf38x9.classList.contains('16') || _0xaf38x9.classList.contains('21') || _0xaf38x9.classList.contains('17') || _0xaf38x9.classList.contains('22') || _0xaf38x9.classList.contains('18') || _0xaf38x9.classList.contains('23') || _0xaf38x9.classList.contains('19') || _0xaf38x9.classList.contains('24') || _0xaf38x9.classList.contains('20') || _0xaf38x9.classList.contains('25')) && null != document.getElementsByClassName((Number(_0xaf38x9.classList[1]) + 5).toString())[0].children[0] && document.getElementsByClassName((Number(_0xaf38x9.classList[1]) + 5).toString())[0].children[0].classList[0] != _0xaf38x9.children[0].classList[0] && null == document.getElementsByClassName((Number(_0xaf38x9.classList[1]) + 10).toString())[0].children[0]) {
                pcEate(document.getElementsByClassName((Number(_0xaf38x9.classList[1]) + 10).toString())[0], document.getElementsByClassName((Number(_0xaf38x9.classList[1]) + 5).toString())[0], _0xaf38x9), _0xaf38xf = !0;
                break
            }
        };
        if (!_0xaf38xf) {
            for (let _0xaf38x8 = 0; _0xaf38x8 < _0xaf38xd.length; _0xaf38x8++) {
                if (_0xaf38x9 = _0xaf38xd[_0xaf38x8].parentElement, !(_0xaf38x9.classList.contains('5') || _0xaf38x9.classList.contains('10') || _0xaf38x9.classList.contains('15') || _0xaf38x9.classList.contains('20') || _0xaf38x9.classList.contains('25') || null != _0xaf38x9.nextElementSibling.children[0] || null == _0xaf38x9.nextElementSibling.nextElementSibling) && (null != _0xaf38x9.nextElementSibling.nextElementSibling.children[0] && _0xaf38x9.nextElementSibling.nextElementSibling.children[0].classList[0] == _0xaf38x9.children[0].classList[0] || null != _0xaf38x9.nextElementSibling.nextElementSibling && null == _0xaf38x9.nextElementSibling.nextElementSibling.children[0])) {
                    makSound('moveSound'), _0xaf38x9.nextElementSibling.appendChild(_0xaf38x9.children[0]), removeSelected(), changeChance(), _0xaf38xf = !0;
                    break
                };
                if (!(_0xaf38x9.classList.contains('1') || _0xaf38x9.classList.contains('6') || _0xaf38x9.classList.contains('11') || _0xaf38x9.classList.contains('16') || _0xaf38x9.classList.contains('21') || null != _0xaf38x9.previousElementSibling.children[0] || null == _0xaf38x9.previousElementSibling.previousElementSibling) && (null != _0xaf38x9.previousElementSibling.previousElementSibling.children[0] && _0xaf38x9.previousElementSibling.previousElementSibling.children[0].classList[0] == _0xaf38x9.children[0].classList[0] || null != _0xaf38x9.previousElementSibling.previousElementSibling && null == _0xaf38x9.previousElementSibling.previousElementSibling.children[0])) {
                    makSound('moveSound'), _0xaf38x9.previousElementSibling.appendChild(_0xaf38x9.children[0]), removeSelected(), changeChance(), _0xaf38xf = !0;
                    break
                };
                if (!(_0xaf38x9.classList.contains('1') || _0xaf38x9.classList.contains('2') || _0xaf38x9.classList.contains('3') || _0xaf38x9.classList.contains('4') || _0xaf38x9.classList.contains('5') || null == document.getElementsByClassName((Number(_0xaf38x9.classList[1]) - 5).toString())[0] || null != document.getElementsByClassName((Number(_0xaf38x9.classList[1]) - 5).toString())[0].children[0]) && (null != document.getElementsByClassName((Number(_0xaf38x9.classList[1]) - 10).toString())[0] && null != document.getElementsByClassName((Number(_0xaf38x9.classList[1]) - 10).toString())[0].children[0] && document.getElementsByClassName((Number(_0xaf38x9.classList[1]) - 10).toString())[0].children[0].classList[0] == _0xaf38x9.children[0].classList[0] || null != document.getElementsByClassName((Number(_0xaf38x9.classList[1]) - 10).toString())[0] && null == document.getElementsByClassName((Number(_0xaf38x9.classList[1]) - 10).toString())[0].children[0])) {
                    makSound('moveSound'), document.getElementsByClassName((Number(_0xaf38x9.classList[1]) - 5).toString())[0].appendChild(_0xaf38x9.children[0]), removeSelected(), changeChance(), _0xaf38xf = !0;
                    break
                };
                if (!(_0xaf38x9.classList.contains('21') || _0xaf38x9.classList.contains('22') || _0xaf38x9.classList.contains('23') || _0xaf38x9.classList.contains('24') || _0xaf38x9.classList.contains('25')) && null != document.getElementsByClassName((Number(_0xaf38x9.classList[1]) + 5).toString())[0] && null == document.getElementsByClassName((Number(_0xaf38x9.classList[1]) + 5).toString())[0].children[0] && (null != document.getElementsByClassName((Number(_0xaf38x9.classList[1]) + 10).toString())[0] && null != document.getElementsByClassName((Number(_0xaf38x9.classList[1]) + 10).toString())[0].children[0] && document.getElementsByClassName((Number(_0xaf38x9.classList[1]) + 10).toString())[0].children[0].classList[0] == _0xaf38x9.children[0].classList[0] || null != document.getElementsByClassName((Number(_0xaf38x9.classList[1]) + 10).toString())[0] && null == document.getElementsByClassName((Number(_0xaf38x9.classList[1]) + 10).toString())[0].children[0])) {
                    makSound('moveSound'), document.getElementsByClassName((Number(_0xaf38x9.classList[1]) + 5).toString())[0].appendChild(_0xaf38x9.children[0]), removeSelected(), changeChance(), _0xaf38xf = !0;
                    break
                }
            }
        };
        if (!_0xaf38xf) {
            for (let _0xaf38x8 = 0; _0xaf38x8 < _0xaf38xd.length; _0xaf38x8++) {
                if (_0xaf38x9 = _0xaf38xd[_0xaf38x8].parentElement, !(_0xaf38x9.classList.contains('5') || _0xaf38x9.classList.contains('10') || _0xaf38x9.classList.contains('15') || _0xaf38x9.classList.contains('20') || _0xaf38x9.classList.contains('25') || null != _0xaf38x9.nextElementSibling.children[0])) {
                    makSound('moveSound'), _0xaf38x9.nextElementSibling.appendChild(_0xaf38x9.children[0]), removeSelected(), changeChance();
                    break
                };
                if (!(_0xaf38x9.classList.contains('1') || _0xaf38x9.classList.contains('6') || _0xaf38x9.classList.contains('11') || _0xaf38x9.classList.contains('16') || _0xaf38x9.classList.contains('21') || null != _0xaf38x9.previousElementSibling.children[0])) {
                    makSound('moveSound'), _0xaf38x9.previousElementSibling.appendChild(_0xaf38x9.children[0]), removeSelected(), changeChance();
                    break
                };
                if (!(_0xaf38x9.classList.contains('1') || _0xaf38x9.classList.contains('2') || _0xaf38x9.classList.contains('3') || _0xaf38x9.classList.contains('4') || _0xaf38x9.classList.contains('5') || null == document.getElementsByClassName((Number(_0xaf38x9.classList[1]) - 5).toString())[0] || null != document.getElementsByClassName((Number(_0xaf38x9.classList[1]) - 5).toString())[0].children[0])) {
                    makSound('moveSound'), document.getElementsByClassName((Number(_0xaf38x9.classList[1]) - 5).toString())[0].appendChild(_0xaf38x9.children[0]), removeSelected(), changeChance();
                    break
                };
                if (!(_0xaf38x9.classList.contains('21') || _0xaf38x9.classList.contains('22') || _0xaf38x9.classList.contains('23') || _0xaf38x9.classList.contains('24') || _0xaf38x9.classList.contains('25')) && null != document.getElementsByClassName((Number(_0xaf38x9.classList[1]) + 5).toString())[0] && null == document.getElementsByClassName((Number(_0xaf38x9.classList[1]) + 5).toString())[0].children[0]) {
                    makSound('moveSound'), document.getElementsByClassName((Number(_0xaf38x9.classList[1]) + 5).toString())[0].appendChild(_0xaf38x9.children[0]), removeSelected(), changeChance();
                    break
                }
            }
        }
    }, 1e3)
}

function pcEate(_0xaf38x8, _0xaf38x9, _0xaf38xd) {
    makSound('eatSound');
    var _0xaf38xe = _0xaf38xd.offsetLeft,
        _0xaf38xf = _0xaf38xd.offsetTop;
    _0xaf38x8.appendChild(_0xaf38xd.children[0]), jump(_0xaf38x8.children[0], _0xaf38xe, _0xaf38xf), setTimeout(() => {
        'f' == _0xaf38x9.children[0].classList[0] ? (out2.appendChild(_0xaf38x9.children[0]), jump(out2.lastElementChild, _0xaf38x9.offsetLeft, _0xaf38x9.offsetTop)) : (out1.appendChild(_0xaf38x9.children[0]), jump(out1.lastElementChild, _0xaf38x9.offsetLeft, _0xaf38x9.offsetTop)), removeSelected(), changeChance(), checkWinner()
    }, 730)
}

function soundTogle(_0xaf38x8, _0xaf38x9) {
    document.querySelectorAll('audio').forEach((_0xaf38x8) => {
        _0xaf38x8.pause()
    }), localStorage.setItem('sound', _0xaf38x8), 'on' == _0xaf38x8 ? (_0xaf38x9.nextElementSibling.style.display = 'unset', _0xaf38x9.style.display = 'none', document.getElementById('clickSound').play(), document.getElementById('clickSound').play()) : (_0xaf38x9.previousElementSibling.style.display = 'unset', _0xaf38x9.style.display = 'none'), sound = localStorage.sound
}
chances(), setInterval(() => {
    7 < error && (changeChance(), error = 0), 'f' == chance && 'computer' == mode && error++
}, 1e3), null == localStorage.sound && localStorage.setItem('sound', 'on');
let sound = localStorage.sound;

function makSound(_0xaf38x8) {
    var _0xaf38x9;
    'on' == sound && ('eatSound' == _0xaf38x8 ? ((_0xaf38x9 = document.createElement('audio')).src = 'sounds/eat0.mp3', document.body.appendChild(_0xaf38x9), _0xaf38x9.play(), _0xaf38x9.onended = function () {
        this.parentNode.removeChild(this)
    }, eatOnly && setTimeout(() => {
        var _0xaf38x8 = document.createElement('audio');
        _0xaf38x8.src = 'sounds/eat1.mp3', document.body.appendChild(_0xaf38x8), _0xaf38x8.play(), _0xaf38x8.onended = function () {
            this.parentNode.removeChild(this)
        }
    }, 500)) : document.getElementById(_0xaf38x8).play())
}
'off' == sound ? (OFF.style.display = 'unset', ON.style.display = 'none') : (OFF.style.display = 'none', ON.style.display = 'unset'), 'on' == sound && setTimeout(() => {
    document.getElementById('startSound').play()
}, 30);